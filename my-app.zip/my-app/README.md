
1 - Primeiro, abra o CMD e navegue até a pasta onde está seu projeto.

2 - Assim que estiver na pasta correta, vamos verificar se o Node.js está instalado. Digite o comando node --version. Se aparecer a versão, ótimo! Caso contrário, será necessário instalar o Node.js.

3 - Para instalar o Node.js, acesse o site oficial em https://nodejs.org/en/download/current e siga as instruções para instalação.

4 - Após concluir a instalação do Node.js, vamos instalar globalmente o Angular CLI. Digite o comando npm install -g @angular/cli.

5 - Pode ser necessário instalar as dependências do seu projeto. Se for o caso, digite npm install.

6 - Agora, navegue até o diretório do seu projeto Angular. Digite cd my-app.

7 - Por fim, para iniciar o servidor e abrir o projeto no navegador, digite ng serve -o.